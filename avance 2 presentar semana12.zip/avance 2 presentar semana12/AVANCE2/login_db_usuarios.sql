-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: login_db
-- ------------------------------------------------------
-- Server version	9.0.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Crear la base de datos si no existe
DROP DATABASE IF EXISTS login_db;
CREATE DATABASE login_db;
USE login_db;

-- Tabla de usuarios del sistema
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    rol ENUM('admin', 'doctor', 'enfermero', 'recepcionista') NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    apellidos VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de pacientes (mantenemos la tabla original para compatibilidad)
CREATE TABLE pacientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    dni VARCHAR(20) NOT NULL UNIQUE,
    nombre VARCHAR(100) NOT NULL,
    apellidos VARCHAR(100) NOT NULL,
    edad INT,
    genero VARCHAR(20),
    direccion TEXT,
    telefono VARCHAR(20),
    email VARCHAR(100),
    antecedentes TEXT,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de notificaciones
CREATE TABLE notificaciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(150),
    mensaje TEXT NOT NULL,
    fecha_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    para_personal_medico BOOLEAN DEFAULT FALSE,
    leida BOOLEAN DEFAULT FALSE
);

-- Tabla de metas
CREATE TABLE metas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    paciente_id INT NOT NULL,
    descripcion TEXT NOT NULL,
    objetivo TEXT,
    progreso INT DEFAULT 0,
    estado VARCHAR(20) DEFAULT 'Pendiente',
    fecha_inicio DATE,
    fecha_fin DATE,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (paciente_id) REFERENCES pacientes(id) ON DELETE CASCADE
);

-- Nuevas tablas del sistema obstétrico
CREATE TABLE hospital_medico (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    direccion VARCHAR(255),
    telefono VARCHAR(20),
    informacion_contacto TEXT
);

CREATE TABLE medico (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    apellido VARCHAR(100),
    especialidad VARCHAR(100),
    sexo ENUM('M', 'F'),
    correo_electronico VARCHAR(100),
    diagnostico TEXT,
    hospital_id INT,
    FOREIGN KEY (hospital_id) REFERENCES hospital_medico(id)
);

CREATE TABLE procedimiento_medico (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo_procedimiento VARCHAR(100),
    detalles TEXT
);

CREATE TABLE procedimiento_actualizar (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATE,
    observaciones TEXT,
    resultados TEXT,
    procedimiento_id INT,
    FOREIGN KEY (procedimiento_id) REFERENCES procedimiento_medico(id)
);

CREATE TABLE visita_medica (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATE,
    observaciones TEXT,
    paciente_id INT,
    medico_id INT,
    FOREIGN KEY (paciente_id) REFERENCES pacientes(id),
    FOREIGN KEY (medico_id) REFERENCES medico(id)
);

CREATE TABLE programa_medico (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre_programa VARCHAR(100),
    descripcion TEXT,
    fecha_inicio DATE,
    responsable VARCHAR(100),
    medico_id INT,
    FOREIGN KEY (medico_id) REFERENCES medico(id)
);

CREATE TABLE meta_anual (
    id INT AUTO_INCREMENT PRIMARY KEY,
    año INT,
    tipo_procedimiento VARCHAR(100),
    cantidad_esperada INT,
    programa_id INT,
    FOREIGN KEY (programa_id) REFERENCES programa_medico(id)
);

CREATE TABLE reporte_programa (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATE,
    evaluacion TEXT,
    estado VARCHAR(50),
    programa_id INT,
    FOREIGN KEY (programa_id) REFERENCES programa_medico(id)
);

CREATE TABLE reporte_procedimiento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATE,
    tipo_procedimiento VARCHAR(100),
    cantidad_realizada INT,
    evaluacion TEXT,
    conclusiones TEXT,
    procedimiento_id INT,
    FOREIGN KEY (procedimiento_id) REFERENCES procedimiento_medico(id)
);

-- Insertar usuario administrador por defecto
INSERT INTO usuarios (username, password, rol, nombre, apellidos, email)
VALUES ('admin', 'admin123', 'admin', 'Administrador', 'Sistema', 'admin@sistema.com');

-- Crear índices para mejorar el rendimiento
CREATE INDEX idx_pacientes_dni ON pacientes(dni);
CREATE INDEX idx_medico_especialidad ON medico(especialidad);
CREATE INDEX idx_visita_fecha ON visita_medica(fecha);
CREATE INDEX idx_programa_fecha ON programa_medico(fecha_inicio);
CREATE INDEX idx_notificaciones_fecha ON notificaciones(fecha_envio);

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-16  0:54:20
