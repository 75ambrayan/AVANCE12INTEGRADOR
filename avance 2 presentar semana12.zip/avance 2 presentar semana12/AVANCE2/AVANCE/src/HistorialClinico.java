import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class HistorialClinico extends JFrame {
    private JComboBox<String> cmbPaciente;
    private JTextArea txtMotivoConsulta;
    private JTextArea txtDiagnostico;
    private JTextArea txtTratamiento;
    private JTextArea txtObservaciones;
    private JTable tablaHistorial;
    private DefaultTableModel modeloTabla;
    private Connection conn;
    private JTextField txtBuscar;
    private int usuarioId = 1; // Temporalmente hardcodeado, debería venir del login

    public HistorialClinico() {
        setTitle("Historial Clínico");
        setSize(1200, 700);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
        conectarBaseDatos();
        cargarPacientes();
        cargarHistorial();
        setVisible(true);
    }

    private void initComponents() {
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        
        // Panel izquierdo - Formulario
        JPanel panelFormulario = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Componentes del formulario
        gbc.gridx = 0; gbc.gridy = 0;
        panelFormulario.add(new JLabel("Paciente:"), gbc);
        gbc.gridx = 1;
        cmbPaciente = new JComboBox<>();
        panelFormulario.add(cmbPaciente, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panelFormulario.add(new JLabel("Motivo de Consulta:"), gbc);
        gbc.gridx = 1;
        txtMotivoConsulta = new JTextArea(4, 30);
        txtMotivoConsulta.setLineWrap(true);
        panelFormulario.add(new JScrollPane(txtMotivoConsulta), gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        panelFormulario.add(new JLabel("Diagnóstico:"), gbc);
        gbc.gridx = 1;
        txtDiagnostico = new JTextArea(4, 30);
        txtDiagnostico.setLineWrap(true);
        panelFormulario.add(new JScrollPane(txtDiagnostico), gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        panelFormulario.add(new JLabel("Tratamiento:"), gbc);
        gbc.gridx = 1;
        txtTratamiento = new JTextArea(4, 30);
        txtTratamiento.setLineWrap(true);
        panelFormulario.add(new JScrollPane(txtTratamiento), gbc);

        gbc.gridx = 0; gbc.gridy = 4;
        panelFormulario.add(new JLabel("Observaciones:"), gbc);
        gbc.gridx = 1;
        txtObservaciones = new JTextArea(4, 30);
        txtObservaciones.setLineWrap(true);
        panelFormulario.add(new JScrollPane(txtObservaciones), gbc);

        // Botones de acción
        JPanel panelBotones = new JPanel(new FlowLayout());
        JButton btnGuardar = new JButton("Guardar Consulta");
        JButton btnLimpiar = new JButton("Limpiar");
        JButton btnGenerarPDF = new JButton("Generar PDF");
        
        btnGuardar.addActionListener(e -> guardarConsulta());
        btnLimpiar.addActionListener(e -> limpiarFormulario());
        btnGenerarPDF.addActionListener(e -> generarPDF());
        
        panelBotones.add(btnGuardar);
        panelBotones.add(btnLimpiar);
        panelBotones.add(btnGenerarPDF);

        gbc.gridx = 0; gbc.gridy = 5;
        gbc.gridwidth = 2;
        panelFormulario.add(panelBotones, gbc);

        // Panel derecho - Tabla y búsqueda
        JPanel panelTabla = new JPanel(new BorderLayout());
        
        // Panel de búsqueda
        JPanel panelBusqueda = new JPanel(new FlowLayout());
        txtBuscar = new JTextField(20);
        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.addActionListener(e -> buscarHistorial());
        panelBusqueda.add(new JLabel("Buscar:"));
        panelBusqueda.add(txtBuscar);
        panelBusqueda.add(btnBuscar);

        // Tabla
        String[] columnas = {"ID", "Paciente", "Fecha Consulta", "Motivo", "Diagnóstico", "Tratamiento"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaHistorial = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tablaHistorial);

        // Configurar el ancho de las columnas
        tablaHistorial.getColumnModel().getColumn(0).setPreferredWidth(50);
        tablaHistorial.getColumnModel().getColumn(1).setPreferredWidth(150);
        tablaHistorial.getColumnModel().getColumn(2).setPreferredWidth(120);
        tablaHistorial.getColumnModel().getColumn(3).setPreferredWidth(200);
        tablaHistorial.getColumnModel().getColumn(4).setPreferredWidth(200);
        tablaHistorial.getColumnModel().getColumn(5).setPreferredWidth(200);

        panelTabla.add(panelBusqueda, BorderLayout.NORTH);
        panelTabla.add(scrollPane, BorderLayout.CENTER);

        // Configurar el SplitPane
        splitPane.setLeftComponent(new JScrollPane(panelFormulario));
        splitPane.setRightComponent(panelTabla);
        splitPane.setDividerLocation(500);

        // Agregar todo al frame
        add(splitPane);

        // Agregar listener para mostrar detalles al seleccionar una fila
        tablaHistorial.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                mostrarDetallesConsulta();
            }
        });
    }

    private void conectarBaseDatos() {
        try {
            String url = "jdbc:mysql://localhost:3306/login_db?allowPublicKeyRetrieval=true&useSSL=false";
            String user = "root";
            String password = "Nigga22";
            conn = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al conectar con la base de datos: " + e.getMessage());
        }
    }

    private void cargarPacientes() {
        try {
            String query = "SELECT id, CONCAT(nombre, ' ', apellidos) as nombre_completo FROM pacientes";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            cmbPaciente.removeAllItems();
            while (rs.next()) {
                String item = rs.getInt("id") + " - " + rs.getString("nombre_completo");
                cmbPaciente.addItem(item);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar pacientes: " + e.getMessage());
        }
    }

    private void cargarHistorial() {
        modeloTabla.setRowCount(0);
        try {
            String query = "SELECT h.*, CONCAT(p.nombre, ' ', p.apellidos) as nombre_paciente " +
                          "FROM historial_clinico h " +
                          "JOIN pacientes p ON h.paciente_id = p.id " +
                          "ORDER BY h.fecha_consulta DESC";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                Object[] fila = {
                    rs.getInt("id"),
                    rs.getString("nombre_paciente"),
                    rs.getTimestamp("fecha_consulta").toLocalDateTime().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")),
                    rs.getString("motivo_consulta"),
                    rs.getString("diagnostico"),
                    rs.getString("tratamiento")
                };
                modeloTabla.addRow(fila);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar historial: " + e.getMessage());
        }
    }

    private void guardarConsulta() {
        try {
            String pacienteSeleccionado = (String) cmbPaciente.getSelectedItem();
            if (pacienteSeleccionado == null) {
                JOptionPane.showMessageDialog(this, "Por favor seleccione un paciente");
                return;
            }
            int pacienteId = Integer.parseInt(pacienteSeleccionado.split(" - ")[0]);

            String sql = "INSERT INTO historial_clinico (paciente_id, fecha_consulta, motivo_consulta, diagnostico, " +
                        "tratamiento, observaciones, usuario_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            
            pstmt.setInt(1, pacienteId);
            pstmt.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
            pstmt.setString(3, txtMotivoConsulta.getText());
            pstmt.setString(4, txtDiagnostico.getText());
            pstmt.setString(5, txtTratamiento.getText());
            pstmt.setString(6, txtObservaciones.getText());
            pstmt.setInt(7, usuarioId);

            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Consulta guardada exitosamente");
            limpiarFormulario();
            cargarHistorial();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al guardar consulta: " + e.getMessage());
        }
    }

    private void buscarHistorial() {
        String busqueda = txtBuscar.getText().trim().toLowerCase();
        modeloTabla.setRowCount(0);
        
        try {
            String sql = "SELECT h.*, CONCAT(p.nombre, ' ', p.apellidos) as nombre_paciente " +
                        "FROM historial_clinico h " +
                        "JOIN pacientes p ON h.paciente_id = p.id " +
                        "WHERE LOWER(p.nombre) LIKE ? OR " +
                        "LOWER(p.apellidos) LIKE ? OR " +
                        "LOWER(h.motivo_consulta) LIKE ? OR " +
                        "LOWER(h.diagnostico) LIKE ? OR " +
                        "LOWER(h.tratamiento) LIKE ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            String termino = "%" + busqueda + "%";
            for (int i = 1; i <= 5; i++) {
                pstmt.setString(i, termino);
            }
            
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Object[] fila = {
                    rs.getInt("id"),
                    rs.getString("nombre_paciente"),
                    rs.getTimestamp("fecha_consulta").toLocalDateTime().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")),
                    rs.getString("motivo_consulta"),
                    rs.getString("diagnostico"),
                    rs.getString("tratamiento")
                };
                modeloTabla.addRow(fila);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al buscar en el historial: " + e.getMessage());
        }
    }

    private void mostrarDetallesConsulta() {
        int filaSeleccionada = tablaHistorial.getSelectedRow();
        if (filaSeleccionada >= 0) {
            try {
                int id = (int) tablaHistorial.getValueAt(filaSeleccionada, 0);
                String sql = "SELECT * FROM historial_clinico WHERE id = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, id);
                
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    // Mostrar los detalles completos en un diálogo
                    StringBuilder detalles = new StringBuilder();
                    detalles.append("Fecha: ").append(rs.getTimestamp("fecha_consulta")).append("\n\n");
                    detalles.append("Motivo de Consulta:\n").append(rs.getString("motivo_consulta")).append("\n\n");
                    detalles.append("Diagnóstico:\n").append(rs.getString("diagnostico")).append("\n\n");
                    detalles.append("Tratamiento:\n").append(rs.getString("tratamiento")).append("\n\n");
                    detalles.append("Observaciones:\n").append(rs.getString("observaciones"));

                    JTextArea textArea = new JTextArea(detalles.toString());
                    textArea.setEditable(false);
                    textArea.setWrapStyleWord(true);
                    textArea.setLineWrap(true);
                    
                    JScrollPane scrollPane = new JScrollPane(textArea);
                    scrollPane.setPreferredSize(new Dimension(500, 400));
                    
                    JOptionPane.showMessageDialog(this, scrollPane, "Detalles de la Consulta", 
                                               JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error al cargar los detalles: " + e.getMessage());
            }
        }
    }

    private void limpiarFormulario() {
        txtMotivoConsulta.setText("");
        txtDiagnostico.setText("");
        txtTratamiento.setText("");
        txtObservaciones.setText("");
    }

    private void generarPDF() {
        int filaSeleccionada = tablaHistorial.getSelectedRow();
        if (filaSeleccionada >= 0) {
            JOptionPane.showMessageDialog(this, "Funcionalidad de generación de PDF en desarrollo");
            // TODO: Implementar la generación de PDF usando iText o similar
        } else {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione una consulta para generar el PDF");
        }
    }
} 