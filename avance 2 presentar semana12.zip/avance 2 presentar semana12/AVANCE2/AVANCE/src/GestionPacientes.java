import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class GestionPacientes extends JFrame {
    private JTextField txtNombre;
    private JTextField txtApellidos;
    private JTextField txtDNI;
    private JTextField txtEdad;
    private JTextArea txtDireccion;
    private JTextField txtTelefono;
    private JTextField txtEmail;
    private JComboBox<String> cmbGenero;
    private JTextArea txtAntecedentes;
    private JTable tablaPacientes;
    private DefaultTableModel modeloTabla;
    private JTextField txtBuscar;
    private Connection conn;

    public GestionPacientes() {
        setTitle("Gestión de Pacientes");
        setSize(1000, 700);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
        conectarBaseDatos();
        cargarPacientes();
        setVisible(true);
    }

    private void initComponents() {
        // Panel principal con división
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        
        // Panel izquierdo - Formulario
        JPanel panelFormulario = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Componentes del formulario
        gbc.gridx = 0; gbc.gridy = 0;
        panelFormulario.add(new JLabel("Nombre:"), gbc);
        gbc.gridx = 1;
        txtNombre = new JTextField(20);
        panelFormulario.add(txtNombre, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panelFormulario.add(new JLabel("Apellidos:"), gbc);
        gbc.gridx = 1;
        txtApellidos = new JTextField(20);
        panelFormulario.add(txtApellidos, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        panelFormulario.add(new JLabel("DNI:"), gbc);
        gbc.gridx = 1;
        txtDNI = new JTextField(20);
        panelFormulario.add(txtDNI, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        panelFormulario.add(new JLabel("Edad:"), gbc);
        gbc.gridx = 1;
        txtEdad = new JTextField(20);
        panelFormulario.add(txtEdad, gbc);

        gbc.gridx = 0; gbc.gridy = 4;
        panelFormulario.add(new JLabel("Género:"), gbc);
        gbc.gridx = 1;
        cmbGenero = new JComboBox<>(new String[]{"Masculino", "Femenino", "Otro"});
        panelFormulario.add(cmbGenero, gbc);

        gbc.gridx = 0; gbc.gridy = 5;
        panelFormulario.add(new JLabel("Dirección:"), gbc);
        gbc.gridx = 1;
        txtDireccion = new JTextArea(3, 20);
        txtDireccion.setLineWrap(true);
        panelFormulario.add(new JScrollPane(txtDireccion), gbc);

        gbc.gridx = 0; gbc.gridy = 6;
        panelFormulario.add(new JLabel("Teléfono:"), gbc);
        gbc.gridx = 1;
        txtTelefono = new JTextField(20);
        panelFormulario.add(txtTelefono, gbc);

        gbc.gridx = 0; gbc.gridy = 7;
        panelFormulario.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1;
        txtEmail = new JTextField(20);
        panelFormulario.add(txtEmail, gbc);

        gbc.gridx = 0; gbc.gridy = 8;
        panelFormulario.add(new JLabel("Antecedentes:"), gbc);
        gbc.gridx = 1;
        txtAntecedentes = new JTextArea(4, 20);
        txtAntecedentes.setLineWrap(true);
        panelFormulario.add(new JScrollPane(txtAntecedentes), gbc);

        // Botones de acción
        JPanel panelBotones = new JPanel(new FlowLayout());
        JButton btnGuardar = new JButton("Guardar");
        JButton btnLimpiar = new JButton("Limpiar");
        JButton btnEliminar = new JButton("Eliminar");
        
        btnGuardar.addActionListener(e -> guardarPaciente());
        btnLimpiar.addActionListener(e -> limpiarFormulario());
        btnEliminar.addActionListener(e -> eliminarPaciente());
        
        panelBotones.add(btnGuardar);
        panelBotones.add(btnLimpiar);
        panelBotones.add(btnEliminar);

        gbc.gridx = 0; gbc.gridy = 9;
        gbc.gridwidth = 2;
        panelFormulario.add(panelBotones, gbc);

        // Panel derecho - Tabla y búsqueda
        JPanel panelTabla = new JPanel(new BorderLayout());
        
        // Panel de búsqueda
        JPanel panelBusqueda = new JPanel(new FlowLayout());
        txtBuscar = new JTextField(20);
        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.addActionListener(e -> buscarPacientes());
        panelBusqueda.add(new JLabel("Buscar:"));
        panelBusqueda.add(txtBuscar);
        panelBusqueda.add(btnBuscar);

        // Tabla
        String[] columnas = {"ID", "DNI", "Nombre", "Apellidos", "Edad", "Género", "Teléfono", "Email"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaPacientes = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tablaPacientes);

        panelTabla.add(panelBusqueda, BorderLayout.NORTH);
        panelTabla.add(scrollPane, BorderLayout.CENTER);

        // Configurar el SplitPane
        splitPane.setLeftComponent(new JScrollPane(panelFormulario));
        splitPane.setRightComponent(panelTabla);
        splitPane.setDividerLocation(400);

        // Agregar todo al frame
        add(splitPane);
    }

    private void conectarBaseDatos() {
        try {
            String url = "jdbc:mysql://localhost:3306/login_db?allowPublicKeyRetrieval=true&useSSL=false";
            String user = "root";
            String password = "Nigga22";
            conn = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al conectar con la base de datos: " + e.getMessage());
        }
    }

    private void cargarPacientes() {
        modeloTabla.setRowCount(0);
        try {
            String query = "SELECT * FROM pacientes";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                Object[] fila = {
                    rs.getInt("id"),
                    rs.getString("dni"),
                    rs.getString("nombre"),
                    rs.getString("apellidos"),
                    rs.getInt("edad"),
                    rs.getString("genero"),
                    rs.getString("telefono"),
                    rs.getString("email")
                };
                modeloTabla.addRow(fila);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar pacientes: " + e.getMessage());
        }
    }

    private void guardarPaciente() {
        try {
            String sql = "INSERT INTO pacientes (dni, nombre, apellidos, edad, genero, direccion, telefono, email, antecedentes) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            
            pstmt.setString(1, txtDNI.getText());
            pstmt.setString(2, txtNombre.getText());
            pstmt.setString(3, txtApellidos.getText());
            pstmt.setInt(4, Integer.parseInt(txtEdad.getText()));
            pstmt.setString(5, cmbGenero.getSelectedItem().toString());
            pstmt.setString(6, txtDireccion.getText());
            pstmt.setString(7, txtTelefono.getText());
            pstmt.setString(8, txtEmail.getText());
            pstmt.setString(9, txtAntecedentes.getText());

            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Paciente guardado exitosamente");
            limpiarFormulario();
            cargarPacientes();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al guardar paciente: " + e.getMessage());
        }
    }

    private void eliminarPaciente() {
        int filaSeleccionada = tablaPacientes.getSelectedRow();
        if (filaSeleccionada >= 0) {
            int id = (int) tablaPacientes.getValueAt(filaSeleccionada, 0);
            try {
                String sql = "DELETE FROM pacientes WHERE id = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, id);
                pstmt.executeUpdate();
                
                JOptionPane.showMessageDialog(this, "Paciente eliminado exitosamente");
                cargarPacientes();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error al eliminar paciente: " + e.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione un paciente para eliminar");
        }
    }

    private void buscarPacientes() {
        String busqueda = txtBuscar.getText().trim().toLowerCase();
        modeloTabla.setRowCount(0);
        
        try {
            String sql = "SELECT * FROM pacientes WHERE " +
                        "LOWER(nombre) LIKE ? OR " +
                        "LOWER(apellidos) LIKE ? OR " +
                        "LOWER(dni) LIKE ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            String termino = "%" + busqueda + "%";
            pstmt.setString(1, termino);
            pstmt.setString(2, termino);
            pstmt.setString(3, termino);
            
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Object[] fila = {
                    rs.getInt("id"),
                    rs.getString("dni"),
                    rs.getString("nombre"),
                    rs.getString("apellidos"),
                    rs.getInt("edad"),
                    rs.getString("genero"),
                    rs.getString("telefono"),
                    rs.getString("email")
                };
                modeloTabla.addRow(fila);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al buscar pacientes: " + e.getMessage());
        }
    }

    private void limpiarFormulario() {
        txtNombre.setText("");
        txtApellidos.setText("");
        txtDNI.setText("");
        txtEdad.setText("");
        cmbGenero.setSelectedIndex(0);
        txtDireccion.setText("");
        txtTelefono.setText("");
        txtEmail.setText("");
        txtAntecedentes.setText("");
    }
} 