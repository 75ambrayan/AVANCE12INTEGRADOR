import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class GestionUsuarios extends JFrame {
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JComboBox<String> cmbRol;
    private JTextField txtNombre;
    private JTextField txtApellidos;
    private JTextField txtEmail;
    private JTable tablaUsuarios;
    private DefaultTableModel modeloTabla;
    private Connection conn;
    private JTextField txtBuscar;

    public GestionUsuarios() {
        setTitle("Gestión de Usuarios");
        setSize(1000, 600);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
        conectarBaseDatos();
        cargarUsuarios();
        setVisible(true);
    }

    private void initComponents() {
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        
        // Panel izquierdo - Formulario
        JPanel panelFormulario = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Componentes del formulario
        gbc.gridx = 0; gbc.gridy = 0;
        panelFormulario.add(new JLabel("Usuario:"), gbc);
        gbc.gridx = 1;
        txtUsername = new JTextField(20);
        panelFormulario.add(txtUsername, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panelFormulario.add(new JLabel("Contraseña:"), gbc);
        gbc.gridx = 1;
        txtPassword = new JPasswordField(20);
        panelFormulario.add(txtPassword, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        panelFormulario.add(new JLabel("Rol:"), gbc);
        gbc.gridx = 1;
        cmbRol = new JComboBox<>(new String[]{"admin", "doctor", "enfermero", "recepcionista"});
        panelFormulario.add(cmbRol, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        panelFormulario.add(new JLabel("Nombre:"), gbc);
        gbc.gridx = 1;
        txtNombre = new JTextField(20);
        panelFormulario.add(txtNombre, gbc);

        gbc.gridx = 0; gbc.gridy = 4;
        panelFormulario.add(new JLabel("Apellidos:"), gbc);
        gbc.gridx = 1;
        txtApellidos = new JTextField(20);
        panelFormulario.add(txtApellidos, gbc);

        gbc.gridx = 0; gbc.gridy = 5;
        panelFormulario.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1;
        txtEmail = new JTextField(20);
        panelFormulario.add(txtEmail, gbc);

        // Botones de acción
        JPanel panelBotones = new JPanel(new FlowLayout());
        JButton btnGuardar = new JButton("Guardar Usuario");
        JButton btnActualizar = new JButton("Actualizar Usuario");
        JButton btnEliminar = new JButton("Eliminar Usuario");
        JButton btnLimpiar = new JButton("Limpiar");
        
        btnGuardar.addActionListener(e -> guardarUsuario());
        btnActualizar.addActionListener(e -> actualizarUsuario());
        btnEliminar.addActionListener(e -> eliminarUsuario());
        btnLimpiar.addActionListener(e -> limpiarFormulario());
        
        panelBotones.add(btnGuardar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnLimpiar);

        gbc.gridx = 0; gbc.gridy = 6;
        gbc.gridwidth = 2;
        panelFormulario.add(panelBotones, gbc);

        // Panel derecho - Tabla y búsqueda
        JPanel panelTabla = new JPanel(new BorderLayout());
        
        // Panel de búsqueda
        JPanel panelBusqueda = new JPanel(new FlowLayout());
        txtBuscar = new JTextField(20);
        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.addActionListener(e -> buscarUsuarios());
        panelBusqueda.add(new JLabel("Buscar:"));
        panelBusqueda.add(txtBuscar);
        panelBusqueda.add(btnBuscar);

        // Tabla
        String[] columnas = {"ID", "Usuario", "Rol", "Nombre", "Apellidos", "Email", "Fecha Creación"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaUsuarios = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tablaUsuarios);

        panelTabla.add(panelBusqueda, BorderLayout.NORTH);
        panelTabla.add(scrollPane, BorderLayout.CENTER);

        // Configurar el SplitPane
        splitPane.setLeftComponent(new JScrollPane(panelFormulario));
        splitPane.setRightComponent(panelTabla);
        splitPane.setDividerLocation(400);

        // Agregar todo al frame
        add(splitPane);

        // Agregar listener para cargar datos al seleccionar una fila
        tablaUsuarios.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                cargarDatosUsuarioSeleccionado();
            }
        });
    }

    private void conectarBaseDatos() {
        try {
            String url = "jdbc:mysql://localhost:3306/login_db?allowPublicKeyRetrieval=true&useSSL=false";
            String user = "root";
            String password = "Nigga22";
            conn = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al conectar con la base de datos: " + e.getMessage());
        }
    }

    private void cargarUsuarios() {
        modeloTabla.setRowCount(0);
        try {
            String query = "SELECT * FROM usuarios ORDER BY fecha_creacion DESC";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                Object[] fila = {
                    rs.getInt("id"),
                    rs.getString("username"),
                    rs.getString("rol"),
                    rs.getString("nombre"),
                    rs.getString("apellidos"),
                    rs.getString("email"),
                    rs.getTimestamp("fecha_creacion")
                };
                modeloTabla.addRow(fila);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar usuarios: " + e.getMessage());
        }
    }

    private void guardarUsuario() {
        try {
            // Validaciones básicas
            if (txtUsername.getText().trim().isEmpty() || new String(txtPassword.getPassword()).trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Usuario y contraseña son obligatorios");
                return;
            }

            String sql = "INSERT INTO usuarios (username, password, rol, nombre, apellidos, email) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            
            pstmt.setString(1, txtUsername.getText().trim());
            pstmt.setString(2, new String(txtPassword.getPassword()));
            pstmt.setString(3, cmbRol.getSelectedItem().toString());
            pstmt.setString(4, txtNombre.getText().trim());
            pstmt.setString(5, txtApellidos.getText().trim());
            pstmt.setString(6, txtEmail.getText().trim());

            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Usuario guardado exitosamente");
            limpiarFormulario();
            cargarUsuarios();
        } catch (SQLException e) {
            if (e.getMessage().contains("Duplicate entry")) {
                JOptionPane.showMessageDialog(this, "El nombre de usuario ya existe");
            } else {
                JOptionPane.showMessageDialog(this, "Error al guardar usuario: " + e.getMessage());
            }
        }
    }

    private void actualizarUsuario() {
        int filaSeleccionada = tablaUsuarios.getSelectedRow();
        if (filaSeleccionada >= 0) {
            try {
                int id = (int) tablaUsuarios.getValueAt(filaSeleccionada, 0);
                String sql = "UPDATE usuarios SET rol = ?, nombre = ?, apellidos = ?, email = ? WHERE id = ?";
                
                // Si se ha ingresado una nueva contraseña, actualizarla también
                if (txtPassword.getPassword().length > 0) {
                    sql = "UPDATE usuarios SET password = ?, rol = ?, nombre = ?, apellidos = ?, email = ? WHERE id = ?";
                }

                PreparedStatement pstmt = conn.prepareStatement(sql);
                int paramIndex = 1;
                
                if (txtPassword.getPassword().length > 0) {
                    pstmt.setString(paramIndex++, new String(txtPassword.getPassword()));
                }
                
                pstmt.setString(paramIndex++, cmbRol.getSelectedItem().toString());
                pstmt.setString(paramIndex++, txtNombre.getText().trim());
                pstmt.setString(paramIndex++, txtApellidos.getText().trim());
                pstmt.setString(paramIndex++, txtEmail.getText().trim());
                pstmt.setInt(paramIndex, id);

                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Usuario actualizado exitosamente");
                limpiarFormulario();
                cargarUsuarios();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error al actualizar usuario: " + e.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione un usuario para actualizar");
        }
    }

    private void eliminarUsuario() {
        int filaSeleccionada = tablaUsuarios.getSelectedRow();
        if (filaSeleccionada >= 0) {
            int id = (int) tablaUsuarios.getValueAt(filaSeleccionada, 0);
            String username = (String) tablaUsuarios.getValueAt(filaSeleccionada, 1);
            
            // No permitir eliminar al usuario admin
            if (username.equals("admin")) {
                JOptionPane.showMessageDialog(this, "No se puede eliminar el usuario administrador");
                return;
            }

            int confirmacion = JOptionPane.showConfirmDialog(this, 
                "¿Está seguro de eliminar el usuario " + username + "?",
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION);

            if (confirmacion == JOptionPane.YES_OPTION) {
                try {
                    String sql = "DELETE FROM usuarios WHERE id = ?";
                    PreparedStatement pstmt = conn.prepareStatement(sql);
                    pstmt.setInt(1, id);
                    pstmt.executeUpdate();
                    
                    JOptionPane.showMessageDialog(this, "Usuario eliminado exitosamente");
                    limpiarFormulario();
                    cargarUsuarios();
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(this, "Error al eliminar usuario: " + e.getMessage());
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione un usuario para eliminar");
        }
    }

    private void buscarUsuarios() {
        String busqueda = txtBuscar.getText().trim().toLowerCase();
        modeloTabla.setRowCount(0);
        
        try {
            String sql = "SELECT * FROM usuarios WHERE " +
                        "LOWER(username) LIKE ? OR " +
                        "LOWER(nombre) LIKE ? OR " +
                        "LOWER(apellidos) LIKE ? OR " +
                        "LOWER(email) LIKE ? OR " +
                        "LOWER(rol) LIKE ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            String termino = "%" + busqueda + "%";
            for (int i = 1; i <= 5; i++) {
                pstmt.setString(i, termino);
            }
            
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Object[] fila = {
                    rs.getInt("id"),
                    rs.getString("username"),
                    rs.getString("rol"),
                    rs.getString("nombre"),
                    rs.getString("apellidos"),
                    rs.getString("email"),
                    rs.getTimestamp("fecha_creacion")
                };
                modeloTabla.addRow(fila);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al buscar usuarios: " + e.getMessage());
        }
    }

    private void cargarDatosUsuarioSeleccionado() {
        int filaSeleccionada = tablaUsuarios.getSelectedRow();
        if (filaSeleccionada >= 0) {
            txtUsername.setText((String) tablaUsuarios.getValueAt(filaSeleccionada, 1));
            txtUsername.setEnabled(false); // No permitir cambiar el username
            cmbRol.setSelectedItem(tablaUsuarios.getValueAt(filaSeleccionada, 2));
            txtNombre.setText((String) tablaUsuarios.getValueAt(filaSeleccionada, 3));
            txtApellidos.setText((String) tablaUsuarios.getValueAt(filaSeleccionada, 4));
            txtEmail.setText((String) tablaUsuarios.getValueAt(filaSeleccionada, 5));
            txtPassword.setText(""); // Limpiar el campo de contraseña
        }
    }

    private void limpiarFormulario() {
        txtUsername.setText("");
        txtUsername.setEnabled(true);
        txtPassword.setText("");
        cmbRol.setSelectedIndex(0);
        txtNombre.setText("");
        txtApellidos.setText("");
        txtEmail.setText("");
        tablaUsuarios.clearSelection();
    }
} 