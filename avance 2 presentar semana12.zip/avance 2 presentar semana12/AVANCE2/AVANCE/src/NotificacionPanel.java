import javax.swing.*;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class NotificacionPanel extends JPanel implements NotificacionUtil.NotificacionListener {
    private JList<String> listaNotificaciones;
    private DefaultListModel<String> modeloLista;
    private List<NotificacionUtil.Notificacion> notificacionesActuales;
    private static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    public NotificacionPanel() {
        setLayout(new BorderLayout());
        initComponents();
        NotificacionUtil.agregarListener(this);
        cargarNotificaciones();
    }

    private void initComponents() {
        // Panel superior con título
        JPanel panelTitulo = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel lblTitulo = new JLabel("Notificaciones");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 14));
        panelTitulo.add(lblTitulo);

        // Lista de notificaciones
        modeloLista = new DefaultListModel<>();
        listaNotificaciones = new JList<>(modeloLista);
        listaNotificaciones.setCellRenderer(new NotificacionCellRenderer());
        JScrollPane scrollPane = new JScrollPane(listaNotificaciones);

        // Panel de botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnMarcarLeida = new JButton("Marcar como leída");
        JButton btnActualizar = new JButton("Actualizar");

        btnMarcarLeida.addActionListener(e -> marcarComoLeida());
        btnActualizar.addActionListener(e -> cargarNotificaciones());

        panelBotones.add(btnMarcarLeida);
        panelBotones.add(btnActualizar);

        // Agregar componentes al panel principal
        add(panelTitulo, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);

        // Agregar listener para doble clic
        listaNotificaciones.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if (evt.getClickCount() == 2) {
                    mostrarDetallesNotificacion();
                }
            }
        });
    }

    private void cargarNotificaciones() {
        modeloLista.clear();
        notificacionesActuales = NotificacionUtil.obtenerNotificacionesNoLeidas();
        
        for (NotificacionUtil.Notificacion notificacion : notificacionesActuales) {
            modeloLista.addElement(formatearNotificacion(notificacion));
        }

        if (modeloLista.isEmpty()) {
            modeloLista.addElement("No hay notificaciones nuevas");
        }
    }

    private String formatearNotificacion(NotificacionUtil.Notificacion notificacion) {
        return String.format("[%s] %s - %s",
            notificacion.getFechaEnvio().format(FORMATO_FECHA),
            notificacion.getTitulo(),
            notificacion.getMensaje());
    }

    private void marcarComoLeida() {
        int indiceSeleccionado = listaNotificaciones.getSelectedIndex();
        if (indiceSeleccionado >= 0 && indiceSeleccionado < notificacionesActuales.size()) {
            NotificacionUtil.Notificacion notificacion = notificacionesActuales.get(indiceSeleccionado);
            NotificacionUtil.marcarComoLeida(notificacion.getId());
            cargarNotificaciones();
        }
    }

    private void mostrarDetallesNotificacion() {
        int indiceSeleccionado = listaNotificaciones.getSelectedIndex();
        if (indiceSeleccionado >= 0 && indiceSeleccionado < notificacionesActuales.size()) {
            NotificacionUtil.Notificacion notificacion = notificacionesActuales.get(indiceSeleccionado);
            
            StringBuilder detalles = new StringBuilder();
            detalles.append("Fecha: ").append(notificacion.getFechaEnvio().format(FORMATO_FECHA)).append("\n\n");
            detalles.append("Título: ").append(notificacion.getTitulo()).append("\n\n");
            detalles.append("Mensaje:\n").append(notificacion.getMensaje()).append("\n\n");
            detalles.append("Para Personal Médico: ").append(notificacion.isParaPersonalMedico() ? "Sí" : "No");

            JTextArea textArea = new JTextArea(detalles.toString());
            textArea.setEditable(false);
            textArea.setWrapStyleWord(true);
            textArea.setLineWrap(true);
            
            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(400, 300));
            
            JOptionPane.showMessageDialog(this, scrollPane, "Detalles de la Notificación", 
                                       JOptionPane.INFORMATION_MESSAGE);
        }
    }

    @Override
    public void onNuevaNotificacion(NotificacionUtil.Notificacion notificacion) {
        // Actualizar la lista en el EDT
        SwingUtilities.invokeLater(() -> {
            cargarNotificaciones();
            // Mostrar una notificación del sistema
            mostrarNotificacionSistema(notificacion);
        });
    }

    private void mostrarNotificacionSistema(NotificacionUtil.Notificacion notificacion) {
        if (SystemTray.isSupported()) {
            try {
                SystemTray tray = SystemTray.getSystemTray();
                Image image = new ImageIcon(getClass().getResource("/icon.png")).getImage();
                TrayIcon trayIcon = new TrayIcon(image, "Notificación");
                trayIcon.setImageAutoSize(true);
                tray.add(trayIcon);
                trayIcon.displayMessage("Nueva Notificación",
                                      notificacion.getMensaje(),
                                      TrayIcon.MessageType.INFO);
                // Remover el icono después de 5 segundos
                new Timer(5000, e -> tray.remove(trayIcon)).start();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    // Renderer personalizado para las notificaciones
    private class NotificacionCellRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, 
                                                    int index, boolean isSelected, boolean cellHasFocus) {
            JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            
            if (index >= 0 && index < notificacionesActuales.size()) {
                NotificacionUtil.Notificacion notificacion = notificacionesActuales.get(index);
                
                // Establecer el icono según si es para personal médico o no
                if (notificacion.isParaPersonalMedico()) {
                    label.setIcon(UIManager.getIcon("OptionPane.warningIcon"));
                } else {
                    label.setIcon(UIManager.getIcon("OptionPane.informationIcon"));
                }
            }
            
            return label;
        }
    }
} 