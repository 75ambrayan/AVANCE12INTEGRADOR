import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;

public class SeguimientoMetas extends JFrame {
    private JComboBox<String> cmbPaciente;
    private JTextArea txtDescripcionMeta;
    private JTextField txtObjetivo;
    private JSpinner spnProgreso;
    private JComboBox<String> cmbEstado;
    private JTextField txtFechaInicio;
    private JTextField txtFechaFin;
    private JTable tablaMetas;
    private DefaultTableModel modeloTabla;
    private Connection conn;
    private JTextField txtBuscar;

    public SeguimientoMetas() {
        setTitle("Seguimiento de Metas");
        setSize(1000, 700);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
        conectarBaseDatos();
        cargarPacientes();
        cargarMetas();
        setVisible(true);
    }

    private void initComponents() {
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        
        // Panel izquierdo - Formulario
        JPanel panelFormulario = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Componentes del formulario
        gbc.gridx = 0; gbc.gridy = 0;
        panelFormulario.add(new JLabel("Paciente:"), gbc);
        gbc.gridx = 1;
        cmbPaciente = new JComboBox<>();
        panelFormulario.add(cmbPaciente, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panelFormulario.add(new JLabel("Descripción de la Meta:"), gbc);
        gbc.gridx = 1;
        txtDescripcionMeta = new JTextArea(4, 20);
        txtDescripcionMeta.setLineWrap(true);
        panelFormulario.add(new JScrollPane(txtDescripcionMeta), gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        panelFormulario.add(new JLabel("Objetivo:"), gbc);
        gbc.gridx = 1;
        txtObjetivo = new JTextField(20);
        panelFormulario.add(txtObjetivo, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        panelFormulario.add(new JLabel("Progreso (%):"), gbc);
        gbc.gridx = 1;
        SpinnerModel spinnerModel = new SpinnerNumberModel(0, 0, 100, 5);
        spnProgreso = new JSpinner(spinnerModel);
        panelFormulario.add(spnProgreso, gbc);

        gbc.gridx = 0; gbc.gridy = 4;
        panelFormulario.add(new JLabel("Estado:"), gbc);
        gbc.gridx = 1;
        cmbEstado = new JComboBox<>(new String[]{"En Progreso", "Completada", "Cancelada", "Pendiente"});
        panelFormulario.add(cmbEstado, gbc);

        gbc.gridx = 0; gbc.gridy = 5;
        panelFormulario.add(new JLabel("Fecha Inicio:"), gbc);
        gbc.gridx = 1;
        txtFechaInicio = new JTextField(LocalDate.now().toString());
        panelFormulario.add(txtFechaInicio, gbc);

        gbc.gridx = 0; gbc.gridy = 6;
        panelFormulario.add(new JLabel("Fecha Fin:"), gbc);
        gbc.gridx = 1;
        txtFechaFin = new JTextField(20);
        panelFormulario.add(txtFechaFin, gbc);

        // Botones de acción
        JPanel panelBotones = new JPanel(new FlowLayout());
        JButton btnGuardar = new JButton("Guardar Meta");
        JButton btnActualizar = new JButton("Actualizar Progreso");
        JButton btnEliminar = new JButton("Eliminar Meta");
        
        btnGuardar.addActionListener(e -> guardarMeta());
        btnActualizar.addActionListener(e -> actualizarProgreso());
        btnEliminar.addActionListener(e -> eliminarMeta());
        
        panelBotones.add(btnGuardar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);

        gbc.gridx = 0; gbc.gridy = 7;
        gbc.gridwidth = 2;
        panelFormulario.add(panelBotones, gbc);

        // Panel derecho - Tabla y búsqueda
        JPanel panelTabla = new JPanel(new BorderLayout());
        
        // Panel de búsqueda
        JPanel panelBusqueda = new JPanel(new FlowLayout());
        txtBuscar = new JTextField(20);
        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.addActionListener(e -> buscarMetas());
        panelBusqueda.add(new JLabel("Buscar:"));
        panelBusqueda.add(txtBuscar);
        panelBusqueda.add(btnBuscar);

        // Tabla
        String[] columnas = {"ID", "Paciente", "Descripción", "Objetivo", "Progreso", "Estado", "Fecha Inicio", "Fecha Fin"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaMetas = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tablaMetas);

        panelTabla.add(panelBusqueda, BorderLayout.NORTH);
        panelTabla.add(scrollPane, BorderLayout.CENTER);

        // Configurar el SplitPane
        splitPane.setLeftComponent(new JScrollPane(panelFormulario));
        splitPane.setRightComponent(panelTabla);
        splitPane.setDividerLocation(400);

        // Agregar todo al frame
        add(splitPane);
    }

    private void conectarBaseDatos() {
        try {
            String url = "jdbc:mysql://localhost:3306/login_db?allowPublicKeyRetrieval=true&useSSL=false";
            String user = "root";
            String password = "Nigga22";
            conn = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al conectar con la base de datos: " + e.getMessage());
        }
    }

    private void cargarPacientes() {
        try {
            String query = "SELECT id, CONCAT(nombre, ' ', apellidos) as nombre_completo FROM pacientes";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            cmbPaciente.removeAllItems();
            while (rs.next()) {
                String item = rs.getInt("id") + " - " + rs.getString("nombre_completo");
                cmbPaciente.addItem(item);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar pacientes: " + e.getMessage());
        }
    }

    private void cargarMetas() {
        modeloTabla.setRowCount(0);
        try {
            String query = "SELECT m.*, CONCAT(p.nombre, ' ', p.apellidos) as nombre_paciente " +
                          "FROM metas m " +
                          "JOIN pacientes p ON m.paciente_id = p.id";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                Object[] fila = {
                    rs.getInt("id"),
                    rs.getString("nombre_paciente"),
                    rs.getString("descripcion"),
                    rs.getString("objetivo"),
                    rs.getInt("progreso") + "%",
                    rs.getString("estado"),
                    rs.getString("fecha_inicio"),
                    rs.getString("fecha_fin")
                };
                modeloTabla.addRow(fila);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar metas: " + e.getMessage());
        }
    }

    private void guardarMeta() {
        try {
            String pacienteSeleccionado = (String) cmbPaciente.getSelectedItem();
            int pacienteId = Integer.parseInt(pacienteSeleccionado.split(" - ")[0]);

            String sql = "INSERT INTO metas (paciente_id, descripcion, objetivo, progreso, estado, fecha_inicio, fecha_fin) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            
            pstmt.setInt(1, pacienteId);
            pstmt.setString(2, txtDescripcionMeta.getText());
            pstmt.setString(3, txtObjetivo.getText());
            pstmt.setInt(4, (Integer) spnProgreso.getValue());
            pstmt.setString(5, cmbEstado.getSelectedItem().toString());
            pstmt.setString(6, txtFechaInicio.getText());
            pstmt.setString(7, txtFechaFin.getText());

            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Meta guardada exitosamente");
            limpiarFormulario();
            cargarMetas();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al guardar meta: " + e.getMessage());
        }
    }

    private void actualizarProgreso() {
        int filaSeleccionada = tablaMetas.getSelectedRow();
        if (filaSeleccionada >= 0) {
            try {
                int id = (int) tablaMetas.getValueAt(filaSeleccionada, 0);
                String sql = "UPDATE metas SET progreso = ?, estado = ? WHERE id = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                
                pstmt.setInt(1, (Integer) spnProgreso.getValue());
                pstmt.setString(2, cmbEstado.getSelectedItem().toString());
                pstmt.setInt(3, id);

                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Progreso actualizado exitosamente");
                cargarMetas();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error al actualizar progreso: " + e.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione una meta para actualizar");
        }
    }

    private void eliminarMeta() {
        int filaSeleccionada = tablaMetas.getSelectedRow();
        if (filaSeleccionada >= 0) {
            try {
                int id = (int) tablaMetas.getValueAt(filaSeleccionada, 0);
                String sql = "DELETE FROM metas WHERE id = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, id);
                pstmt.executeUpdate();
                
                JOptionPane.showMessageDialog(this, "Meta eliminada exitosamente");
                cargarMetas();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error al eliminar meta: " + e.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione una meta para eliminar");
        }
    }

    private void buscarMetas() {
        String busqueda = txtBuscar.getText().trim().toLowerCase();
        modeloTabla.setRowCount(0);
        
        try {
            String sql = "SELECT m.*, CONCAT(p.nombre, ' ', p.apellidos) as nombre_paciente " +
                        "FROM metas m " +
                        "JOIN pacientes p ON m.paciente_id = p.id " +
                        "WHERE LOWER(p.nombre) LIKE ? OR " +
                        "LOWER(p.apellidos) LIKE ? OR " +
                        "LOWER(m.descripcion) LIKE ? OR " +
                        "LOWER(m.objetivo) LIKE ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            String termino = "%" + busqueda + "%";
            for (int i = 1; i <= 4; i++) {
                pstmt.setString(i, termino);
            }
            
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Object[] fila = {
                    rs.getInt("id"),
                    rs.getString("nombre_paciente"),
                    rs.getString("descripcion"),
                    rs.getString("objetivo"),
                    rs.getInt("progreso") + "%",
                    rs.getString("estado"),
                    rs.getString("fecha_inicio"),
                    rs.getString("fecha_fin")
                };
                modeloTabla.addRow(fila);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al buscar metas: " + e.getMessage());
        }
    }

    private void limpiarFormulario() {
        txtDescripcionMeta.setText("");
        txtObjetivo.setText("");
        spnProgreso.setValue(0);
        cmbEstado.setSelectedIndex(0);
        txtFechaInicio.setText(LocalDate.now().toString());
        txtFechaFin.setText("");
    }
} 