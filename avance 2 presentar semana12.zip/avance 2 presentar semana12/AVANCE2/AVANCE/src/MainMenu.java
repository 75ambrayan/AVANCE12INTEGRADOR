import javax.swing.*;
import java.awt.*;
import java.sql.Connection;

public class MainMenu extends JFrame {
    private JButton btnPacientes;
    private JButton btnMetas;
    private JButton btnReportes;
    private JButton btnHistorialClinico;
    private JButton btnUsuarios;
    private JButton btnConfiguracion;
    private NotificacionPanel panelNotificaciones;
    private Connection conn;

    public MainMenu(Connection conn) {
        this.conn = conn;
        setTitle("Sistema de Gestión Clínica");
        setSize(1200, 800);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Inicializar NotificacionUtil antes de crear cualquier componente
        NotificacionUtil.inicializar(conn);
        
        initComponents();
        inicializarNotificaciones();
        setVisible(true);
    }

    private void initComponents() {
        // Panel principal con BorderLayout
        setLayout(new BorderLayout());

        // Panel superior con información y botón regresar
        JPanel topPanel = new JPanel(new BorderLayout());
        
        // Botón regresar
        JButton btnRegresar = new JButton("Cerrar Sesión");
        btnRegresar.setFont(new Font("Arial", Font.PLAIN, 14));
        btnRegresar.setBackground(new Color(231, 76, 60));
        btnRegresar.setForeground(Color.WHITE);
        btnRegresar.setFocusPainted(false);
        btnRegresar.addActionListener(e -> cerrarSesion());
        JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        leftPanel.add(btnRegresar);
        topPanel.add(leftPanel, BorderLayout.WEST);
        
        JLabel welcomeLabel = new JLabel("Sistema de Gestión Clínica", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        topPanel.add(welcomeLabel, BorderLayout.CENTER);

        // Panel central con los botones principales
        JPanel mainPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Crear botones con iconos
        btnPacientes = createMenuButton("Gestión de Pacientes", "👤");
        btnMetas = createMenuButton("Seguimiento de Metas", "🎯");
        btnReportes = createMenuButton("Reportes y Gráficos", "📊");
        btnHistorialClinico = createMenuButton("Historial Clínico", "📋");
        btnUsuarios = createMenuButton("Gestión de Usuarios", "👥");
        btnConfiguracion = createMenuButton("Configuración", "⚙️");

        // Agregar botones al panel
        gbc.gridx = 0; gbc.gridy = 0;
        mainPanel.add(btnPacientes, gbc);

        gbc.gridx = 1;
        mainPanel.add(btnMetas, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        mainPanel.add(btnReportes, gbc);

        gbc.gridx = 1;
        mainPanel.add(btnHistorialClinico, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        mainPanel.add(btnUsuarios, gbc);

        gbc.gridx = 1;
        mainPanel.add(btnConfiguracion, gbc);

        // Panel derecho para notificaciones
        panelNotificaciones = new NotificacionPanel();
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBorder(BorderFactory.createTitledBorder("Centro de Notificaciones"));
        rightPanel.add(panelNotificaciones, BorderLayout.CENTER);

        // Agregar acciones a los botones
        btnPacientes.addActionListener(e -> abrirGestionPacientes());
        btnMetas.addActionListener(e -> abrirSeguimientoMetas());
        btnReportes.addActionListener(e -> abrirReportes());
        btnHistorialClinico.addActionListener(e -> abrirHistorialClinico());
        btnUsuarios.addActionListener(e -> abrirGestionUsuarios());
        btnConfiguracion.addActionListener(e -> abrirConfiguracion());

        // Crear un JSplitPane para dividir el panel principal y las notificaciones
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, mainPanel, rightPanel);
        splitPane.setDividerLocation(800);

        // Agregar componentes al frame
        add(topPanel, BorderLayout.NORTH);
        add(splitPane, BorderLayout.CENTER);

        // Agregar barra de estado
        JPanel statusBar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statusBar.setBorder(BorderFactory.createEtchedBorder());
        JLabel statusLabel = new JLabel("Conectado al sistema");
        statusBar.add(statusLabel);
        add(statusBar, BorderLayout.SOUTH);
    }

    private void inicializarNotificaciones() {
        // Iniciar verificación periódica de metas
        Timer timer = new Timer(300000, e -> { // Cada 5 minutos
            NotificacionUtil.verificarMetasVencidas();
            NotificacionUtil.verificarProgresoMetas();
        });
        timer.start();
    }

    private JButton createMenuButton(String text, String icon) {
        JButton button = new JButton(String.format("%s %s", icon, text));
        button.setFont(new Font("Arial", Font.PLAIN, 16));
        button.setPreferredSize(new Dimension(250, 80));
        return button;
    }

    private void abrirGestionPacientes() {
        new GestionPacientes();
    }

    private void abrirSeguimientoMetas() {
        new SeguimientoMetas();
    }

    private void abrirReportes() {
        // TODO: Implementar la ventana de reportes
        JOptionPane.showMessageDialog(this, "Funcionalidad de reportes en desarrollo");
    }

    private void abrirHistorialClinico() {
        new HistorialClinico();
    }

    private void abrirGestionUsuarios() {
        new GestionUsuarios();
    }

    private void abrirConfiguracion() {
        // TODO: Implementar la ventana de configuración
        JOptionPane.showMessageDialog(this, "Funcionalidad de configuración en desarrollo");
    }

    private void cerrarSesion() {
        int confirmacion = JOptionPane.showConfirmDialog(
            this,
            "¿Está seguro que desea cerrar sesión?",
            "Confirmar Cierre de Sesión",
            JOptionPane.YES_NO_OPTION
        );

        if (confirmacion == JOptionPane.YES_OPTION) {
            this.dispose();
            new LoginApp();
        }
    }

    @Override
    public void dispose() {
        NotificacionUtil.detener();
        super.dispose();
    }
} 