import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.Random;

public class LoginApp extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextField captchaInput;
    private JLabel captchaLabel;
    private JCheckBox rememberMeCheck;
    private JCheckBox privacyCheck;
    private JButton loginButton;
    private JButton cancelButton;
    private JPanel mainPanel;

    private String currentCaptcha;
    private int attemptsLeft = 3;
    private Connection conn;

    public LoginApp() {
        setTitle("Sistema de Gestión Clínica - Login");
        setSize(400, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Establecer un color de fondo agradable
        mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                Color color1 = new Color(135, 206, 235); // Azul cielo
                Color color2 = new Color(255, 255, 255); // Blanco
                GradientPaint gp = new GradientPaint(0, 0, color1, 0, getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        
        initComponents();
        generateCaptcha();
        connectToDatabase();
        setVisible(true);
    }

    private void initComponents() {
        mainPanel.setLayout(null); // Usar absolute layout para mayor control
        setContentPane(mainPanel);

        // Logo o título con diseño mejorado
        JLabel titleLabel = new JLabel("Sistema de Gestión Clínica", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(new Color(44, 62, 80));
        titleLabel.setBounds(50, 30, 300, 40);
        mainPanel.add(titleLabel);

        // Subtítulo
        JLabel subtitleLabel = new JLabel("Inicio de Sesión", SwingConstants.CENTER);
        subtitleLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        subtitleLabel.setForeground(new Color(52, 73, 94));
        subtitleLabel.setBounds(50, 70, 300, 30);
        mainPanel.add(subtitleLabel);

        // Panel para los campos de entrada
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(null);
        inputPanel.setOpaque(false);
        inputPanel.setBounds(50, 120, 300, 400);

        // Campos de entrada con diseño mejorado
        JLabel userLabel = new JLabel("Usuario:");
        userLabel.setBounds(0, 20, 280, 25);
        inputPanel.add(userLabel);

        usernameField = new JTextField();
        usernameField.setBounds(0, 45, 280, 35);
        usernameField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(52, 152, 219)),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)));
        inputPanel.add(usernameField);

        JLabel passLabel = new JLabel("Contraseña:");
        passLabel.setBounds(0, 90, 280, 25);
        inputPanel.add(passLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(0, 115, 280, 35);
        passwordField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(52, 152, 219)),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)));
        inputPanel.add(passwordField);

        JLabel captchaTitle = new JLabel("Captcha:");
        captchaTitle.setBounds(0, 160, 280, 25);
        inputPanel.add(captchaTitle);

        captchaLabel = new JLabel();
        captchaLabel.setHorizontalAlignment(SwingConstants.CENTER);
        captchaLabel.setBounds(0, 185, 280, 35);
        captchaLabel.setOpaque(true);
        captchaLabel.setBackground(new Color(236, 240, 241));
        captchaLabel.setFont(new Font("Arial", Font.BOLD, 20));
        inputPanel.add(captchaLabel);

        captchaInput = new JTextField();
        captchaInput.setBounds(0, 230, 280, 35);
        captchaInput.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(52, 152, 219)),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)));
        inputPanel.add(captchaInput);

        // Checkboxes con diseño mejorado
        rememberMeCheck = new JCheckBox("Recordar usuario");
        rememberMeCheck.setBounds(0, 275, 280, 25);
        rememberMeCheck.setOpaque(false);
        inputPanel.add(rememberMeCheck);

        privacyCheck = new JCheckBox("Acepto la política de privacidad");
        privacyCheck.setBounds(0, 305, 280, 25);
        privacyCheck.setOpaque(false);
        privacyCheck.addActionListener(e -> mostrarTerminosYCondiciones());
        inputPanel.add(privacyCheck);

        // Botones con diseño mejorado
        loginButton = new JButton("Ingresar");
        loginButton.setBounds(0, 345, 135, 40);
        loginButton.setBackground(new Color(52, 152, 219));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);
        loginButton.addActionListener(e -> login());
        inputPanel.add(loginButton);

        cancelButton = new JButton("Cancelar");
        cancelButton.setBounds(145, 345, 135, 40);
        cancelButton.setBackground(new Color(231, 76, 60));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFocusPainted(false);
        cancelButton.addActionListener(e -> clearFields());
        inputPanel.add(cancelButton);

        mainPanel.add(inputPanel);
    }

    private void mostrarTerminosYCondiciones() {
        if (privacyCheck.isSelected()) {
            String terminos = "TÉRMINOS Y CONDICIONES DE USO\n\n" +
                "1. CONFIDENCIALIDAD\n" +
                "   - Toda la información manejada en el sistema es confidencial.\n" +
                "   - El usuario se compromete a no divulgar información sensible.\n\n" +
                "2. RESPONSABILIDAD\n" +
                "   - El usuario es responsable de mantener seguras sus credenciales.\n" +
                "   - Cualquier actividad realizada con su cuenta será su responsabilidad.\n\n" +
                "3. USO DEL SISTEMA\n" +
                "   - El sistema debe utilizarse únicamente para fines profesionales.\n" +
                "   - Se prohíbe el uso indebido de la información de pacientes.\n\n" +
                "4. PROTECCIÓN DE DATOS\n" +
                "   - Los datos se manejan según las leyes de protección de datos vigentes.\n" +
                "   - Se implementan medidas de seguridad para proteger la información.\n\n" +
                "¿Acepta estos términos y condiciones?";

            int respuesta = JOptionPane.showConfirmDialog(
                this,
                new JScrollPane(new JTextArea(terminos)),
                "Términos y Condiciones",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.PLAIN_MESSAGE
            );

            if (respuesta != JOptionPane.YES_OPTION) {
                privacyCheck.setSelected(false);
            }
        }
    }

    private void generateCaptcha() {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        Random rnd = new Random();
        StringBuilder sb = new StringBuilder(5);
        for(int i = 0; i < 5; i++) {
            sb.append(chars.charAt(rnd.nextInt(chars.length())));
        }
        currentCaptcha = sb.toString();
        captchaLabel.setText(currentCaptcha);
    }

    private void clearFields() {
        usernameField.setText("");
        passwordField.setText("");
        captchaInput.setText("");
        privacyCheck.setSelected(false);
        rememberMeCheck.setSelected(false);
        generateCaptcha();
    }

    private void connectToDatabase() {
        try {
            // Primero conectar al servidor MySQL sin especificar base de datos
            String serverUrl = "jdbc:mysql://localhost:3306?allowPublicKeyRetrieval=true&useSSL=false";
            String user = "root";
            String password = "Nigga22";

            // Cargar el driver explícitamente
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Conectar al servidor
            Connection serverConn = DriverManager.getConnection(serverUrl, user, password);
            
            // Crear la base de datos si no existe
            try (Statement stmt = serverConn.createStatement()) {
                stmt.executeUpdate("CREATE DATABASE IF NOT EXISTS login_db");
                
                // Usar la base de datos
                stmt.executeUpdate("USE login_db");
                
                // Crear las tablas necesarias
                crearTablas(stmt);
            }
            
            // Cerrar la conexión al servidor y abrir una nueva a la base de datos específica
            serverConn.close();
            
            // Conectar a la base de datos específica
            String dbUrl = "jdbc:mysql://localhost:3306/login_db?allowPublicKeyRetrieval=true&useSSL=false";
            conn = DriverManager.getConnection(dbUrl, user, password);
            System.out.println("Conexión exitosa a la base de datos.");
            
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "No se encontró el driver JDBC de MySQL.");
            System.exit(1);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al conectar con la base de datos: " + e.getMessage());
            System.exit(1);
        }
    }

    private void crearTablas(Statement stmt) throws SQLException {
        // Primero, eliminar las tablas si existen para evitar problemas de estructura
        try {
            stmt.executeUpdate("DROP TABLE IF EXISTS metas");
            stmt.executeUpdate("DROP TABLE IF EXISTS notificaciones");
            stmt.executeUpdate("DROP TABLE IF EXISTS pacientes");
            stmt.executeUpdate("DROP TABLE IF EXISTS usuarios");
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Tabla usuarios
        stmt.executeUpdate("CREATE TABLE usuarios (" +
            "id INT AUTO_INCREMENT PRIMARY KEY," +
            "username VARCHAR(50) NOT NULL UNIQUE," +
            "password VARCHAR(100) NOT NULL," +
            "rol ENUM('admin', 'doctor', 'enfermero', 'recepcionista') NOT NULL," +
            "nombre VARCHAR(100) NOT NULL," +
            "apellidos VARCHAR(100) NOT NULL," +
            "email VARCHAR(100) UNIQUE," +
            "fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Tabla pacientes
        stmt.executeUpdate("CREATE TABLE pacientes (" +
            "id INT AUTO_INCREMENT PRIMARY KEY," +
            "dni VARCHAR(20) NOT NULL UNIQUE," +
            "nombre VARCHAR(100) NOT NULL," +
            "apellidos VARCHAR(100) NOT NULL," +
            "edad INT," +
            "genero VARCHAR(20)," +
            "direccion TEXT," +
            "telefono VARCHAR(20)," +
            "email VARCHAR(100)," +
            "antecedentes TEXT," +
            "fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Tabla notificaciones
        stmt.executeUpdate("CREATE TABLE notificaciones (" +
            "id INT AUTO_INCREMENT PRIMARY KEY," +
            "titulo VARCHAR(150)," +
            "mensaje TEXT NOT NULL," +
            "fecha_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
            "para_personal_medico BOOLEAN DEFAULT FALSE," +
            "leida BOOLEAN DEFAULT FALSE" +
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Tabla metas
        stmt.executeUpdate("CREATE TABLE metas (" +
            "id INT AUTO_INCREMENT PRIMARY KEY," +
            "paciente_id INT NOT NULL," +
            "descripcion TEXT NOT NULL," +
            "objetivo TEXT," +
            "progreso INT DEFAULT 0," +
            "estado VARCHAR(20) DEFAULT 'Pendiente'," +
            "fecha_inicio DATE," +
            "fecha_fin DATE," +
            "fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
            "FOREIGN KEY (paciente_id) REFERENCES pacientes(id) ON DELETE CASCADE" +
            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Insertar usuario administrador por defecto
        stmt.executeUpdate("INSERT INTO usuarios (username, password, rol, nombre, apellidos, email) " +
            "VALUES ('admin', 'admin123', 'admin', 'Administrador', 'Sistema', 'admin@sistema.com')");

        // Crear índices
        stmt.executeUpdate("CREATE INDEX idx_pacientes_dni ON pacientes(dni)");
        stmt.executeUpdate("CREATE INDEX idx_notificaciones_fecha ON notificaciones(fecha_envio)");
    }

    private void login() {
        if(attemptsLeft <= 0) {
            JOptionPane.showMessageDialog(this, "Has agotado el número máximo de intentos.");
            System.exit(0);
            return;
        }

        String user = usernameField.getText().trim();
        String pass = new String(passwordField.getPassword());
        String captchaEntered = captchaInput.getText().trim();

        if(user.isEmpty()) {
            JOptionPane.showMessageDialog(this, "El usuario no puede estar vacío.");
            return;
        }

        if(pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "La contraseña no puede estar vacía.");
            return;
        }

        if(!captchaEntered.equalsIgnoreCase(currentCaptcha)) {
            JOptionPane.showMessageDialog(this, "Captcha incorrecto.");
            attemptsLeft--;
            generateCaptcha();
            return;
        }

        if(!privacyCheck.isSelected()) {
            JOptionPane.showMessageDialog(this, "Debes aceptar la política de privacidad.");
            return;
        }

        String sql = "SELECT * FROM usuarios WHERE username = ? AND password = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, user);
            stmt.setString(2, pass);

            ResultSet rs = stmt.executeQuery();

            if(rs.next()) {
                JOptionPane.showMessageDialog(this, "¡Login exitoso!");
                attemptsLeft = 3;
                if(rememberMeCheck.isSelected()) {
                    // Guardar usuario para recordar en futuras sesiones
                }
                // Crear y mostrar el menú principal
                SwingUtilities.invokeLater(() -> {
                    MainMenu mainMenu = new MainMenu(conn);
                    mainMenu.setVisible(true);
                    this.dispose(); // Cerrar la ventana de login
                });
            } else {
                attemptsLeft--;
                JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos. Intentos restantes: " + attemptsLeft);
                generateCaptcha();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al ejecutar la consulta.");
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        SwingUtilities.invokeLater(LoginApp::new);
    }
}
