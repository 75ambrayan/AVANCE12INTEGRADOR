import javax.swing.*;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class NotificacionUtil {
    private static Connection conn;
    private static final int INTERVALO_VERIFICACION = 60000; // 1 minuto
    private static Timer timer;
    private static List<NotificacionListener> listeners = new ArrayList<>();

    public interface NotificacionListener {
        void onNuevaNotificacion(Notificacion notificacion);
    }

    public static class Notificacion {
        private int id;
        private String titulo;
        private String mensaje;
        private LocalDateTime fechaEnvio;
        private boolean leida;
        private boolean paraPersonalMedico;

        public Notificacion(int id, String titulo, String mensaje, LocalDateTime fechaEnvio, boolean leida, boolean paraPersonalMedico) {
            this.id = id;
            this.titulo = titulo;
            this.mensaje = mensaje;
            this.fechaEnvio = fechaEnvio;
            this.leida = leida;
            this.paraPersonalMedico = paraPersonalMedico;
        }

        public int getId() { return id; }
        public String getTitulo() { return titulo; }
        public String getMensaje() { return mensaje; }
        public LocalDateTime getFechaEnvio() { return fechaEnvio; }
        public boolean isLeida() { return leida; }
        public boolean isParaPersonalMedico() { return paraPersonalMedico; }
    }

    public static void inicializar(Connection conexion) {
        conn = conexion;
        iniciarVerificacionPeriodica();
    }

    public static void agregarListener(NotificacionListener listener) {
        listeners.add(listener);
    }

    public static void removerListener(NotificacionListener listener) {
        listeners.remove(listener);
    }

    private static void iniciarVerificacionPeriodica() {
        timer = new Timer(INTERVALO_VERIFICACION, e -> verificarNuevasNotificaciones());
        timer.start();
    }

    public static void detener() {
        if (timer != null) {
            timer.stop();
        }
    }

    private static void verificarNuevasNotificaciones() {
        try {
            String sql = "SELECT * FROM notificaciones WHERE leida = false ORDER BY fecha_envio DESC";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Notificacion notificacion = new Notificacion(
                    rs.getInt("id"),
                    rs.getString("titulo"),
                    rs.getString("mensaje"),
                    rs.getTimestamp("fecha_envio").toLocalDateTime(),
                    rs.getBoolean("leida"),
                    rs.getBoolean("para_personal_medico")
                );

                // Notificar a todos los listeners
                for (NotificacionListener listener : listeners) {
                    listener.onNuevaNotificacion(notificacion);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void crearNotificacion(String titulo, String mensaje, boolean paraPersonalMedico) {
        try {
            String sql = "INSERT INTO notificaciones (titulo, mensaje, fecha_envio, para_personal_medico, leida) VALUES (?, ?, ?, ?, false)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            
            pstmt.setString(1, titulo);
            pstmt.setString(2, mensaje);
            pstmt.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
            pstmt.setBoolean(4, paraPersonalMedico);

            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al crear notificación: " + e.getMessage());
        }
    }

    public static void marcarComoLeida(int notificacionId) {
        try {
            String sql = "UPDATE notificaciones SET leida = true WHERE id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, notificacionId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al marcar notificación como leída: " + e.getMessage());
        }
    }

    public static List<Notificacion> obtenerNotificacionesNoLeidas() {
        List<Notificacion> notificaciones = new ArrayList<>();
        try {
            String sql = "SELECT * FROM notificaciones WHERE leida = false ORDER BY fecha_envio DESC";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                notificaciones.add(new Notificacion(
                    rs.getInt("id"),
                    rs.getString("titulo"),
                    rs.getString("mensaje"),
                    rs.getTimestamp("fecha_envio").toLocalDateTime(),
                    rs.getBoolean("leida"),
                    rs.getBoolean("para_personal_medico")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return notificaciones;
    }

    public static void verificarMetasVencidas() {
        try {
            String sql = "SELECT m.*, CONCAT(p.nombre, ' ', p.apellidos) as nombre_paciente " +
                        "FROM metas m " +
                        "JOIN pacientes p ON m.paciente_id = p.id " +
                        "WHERE m.fecha_fin < CURRENT_DATE " +
                        "AND m.estado NOT IN ('Completada', 'Cancelada') " +
                        "AND NOT EXISTS (SELECT 1 FROM Notificacion n " +
                        "                WHERE n.Mensaje LIKE CONCAT('%', p.nombre, '%') " +
                        "                AND DATE(n.FechaEnvio) = CURRENT_DATE)";
            
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                String mensaje = "Meta vencida para el paciente " + rs.getString("nombre_paciente") + 
                               ": " + rs.getString("descripcion");
                crearNotificacion("Meta Vencida", mensaje, true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void verificarProgresoMetas() {
        try {
            String sql = "SELECT m.*, CONCAT(p.nombre, ' ', p.apellidos) as nombre_paciente " +
                        "FROM metas m " +
                        "JOIN pacientes p ON m.paciente_id = p.id " +
                        "WHERE m.progreso < 50 " +
                        "AND m.estado = 'En Progreso' " +
                        "AND DATEDIFF(m.fecha_fin, CURRENT_DATE) <= 7 " +
                        "AND NOT EXISTS (SELECT 1 FROM Notificacion n " +
                        "                WHERE n.Mensaje LIKE CONCAT('%', p.nombre, '%') " +
                        "                AND DATE(n.FechaEnvio) = CURRENT_DATE)";
            
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                String mensaje = "Progreso bajo en meta para " + rs.getString("nombre_paciente") + 
                               ". Progreso actual: " + rs.getInt("progreso") + "%";
                crearNotificacion("Alerta de Progreso", mensaje, true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
} 